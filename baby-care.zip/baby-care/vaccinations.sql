-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2024 at 05:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vaccinations`
--

-- --------------------------------------------------------

--
-- Table structure for table `babyprofile`
--

CREATE TABLE `babyprofile` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `ageYear` int(11) DEFAULT NULL,
  `ageMonth` int(11) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `bloodGroup` varchar(5) DEFAULT NULL,
  `parentName` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contactNo` varchar(15) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `babyprofile`
--

INSERT INTO `babyprofile` (`id`, `name`, `ageYear`, `ageMonth`, `dob`, `gender`, `weight`, `height`, `bloodGroup`, `parentName`, `email`, `contactNo`, `address`) VALUES
(6, 'nethu', 1, 2, '2021-03-04', '', 15.00, 71, '', ' perera', 'perera@gmail.com', '071-735-7865', 'Matara'),
(7, 'asd', 1, 2, '2024-10-07', ' male', 12.00, 121, '  b+', ' saman', 'saman@gmail.com', '074-764-6789', ' matara'),
(8, 'kavi', 2, 2, '0000-00-00', ' Female', 12.00, 80, '  o-', ' saman', 'perera@gmail.com', '075-456-4567', ' matara');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `childId` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `username`, `email`, `phone_number`, `childId`, `question`, `answer`) VALUES
(7, 'IT23780156', 'meedum228@gmail.com', '0118848484', 546464, 'adasdadadada', 'qsqsqs'),
(8, 'IT23780156@my.sliit.lk', 'pasii@gmail.com', '0782515544', 14, 'qwert', NULL),
(9, 'IT23780156@my.sliit.', 'pasii@gmail.com', '0782515544', 14, 'qwert', NULL),
(10, 'IT23780156@my', 'pasii@gmail.com', '0782515544', 14, 'qwert', NULL),
(11, 'ghvjh', 'pasii@gmail.com', '0782515544', 14, 'qwert', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(10) NOT NULL,
  `User_Type` varchar(10) NOT NULL,
  `First_Name` varchar(10) NOT NULL,
  `Last_Name` varchar(10) NOT NULL,
  `User_Name` varchar(10) NOT NULL,
  `Contact_number` int(10) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `confirm_password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `User_Type`, `First_Name`, `Last_Name`, `User_Name`, `Contact_number`, `Email`, `password`, `confirm_password`) VALUES
(17, ' health ', ' seethaaaa', ' gamage ', 'seeth', 713234354, 'meedum228@gmail.com', '567', '567'),
(23, ' user ', ' isurini ', ' navodya ', 'isu', 716530225, ' landegenavodya@gmai', '12#', '12#'),
(24, ' user ', ' isurini ', ' navodya ', 'isu', 716530225, ' landegenavodya@gmai', '12#', '12#'),
(25, ' user ', ' isurini ', ' navodya ', 'isu', 716530225, ' landegenavodya@gmai', '123', '123'),
(26, ' admin ', ' pasindu ', ' dasanayak', 'pasi', 762758512, 'pasi@gmail.com', '2255680', '2255680');

-- --------------------------------------------------------

--
-- Table structure for table `vaccinations`
--

CREATE TABLE `vaccinations` (
  `Vaccine_ID` int(11) NOT NULL,
  `baby_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `vaccine_name` varchar(100) NOT NULL,
  `NumberOfDose` decimal(5,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vaccinations`
--

INSERT INTO `vaccinations` (`Vaccine_ID`, `baby_id`, `date`, `vaccine_name`, `NumberOfDose`, `created_at`) VALUES
(1, NULL, '2024-10-01', 'GG', 0.03, NULL),
(2, 0, '2024-09-30', 'gg', 0.06, NULL),
(3, 0, '2024-10-01', 'hiov', 0.06, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vaccine`
--

CREATE TABLE `vaccine` (
  `Vaccine_ID` int(11) NOT NULL,
  `Age` int(11) DEFAULT NULL,
  `NumberOfDose` int(11) DEFAULT NULL,
  `VaccineName` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vaccine`
--

INSERT INTO `vaccine` (`Vaccine_ID`, `Age`, `NumberOfDose`, `VaccineName`) VALUES
(3, 1, 3, 'ghjkkl');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `babyprofile`
--
ALTER TABLE `babyprofile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `vaccinations`
--
ALTER TABLE `vaccinations`
  ADD PRIMARY KEY (`Vaccine_ID`);

--
-- Indexes for table `vaccine`
--
ALTER TABLE `vaccine`
  ADD PRIMARY KEY (`Vaccine_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `babyprofile`
--
ALTER TABLE `babyprofile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `vaccinations`
--
ALTER TABLE `vaccinations`
  MODIFY `Vaccine_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vaccine`
--
ALTER TABLE `vaccine`
  MODIFY `Vaccine_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
