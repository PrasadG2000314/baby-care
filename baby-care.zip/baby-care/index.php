<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baby Care - Your Little One's Best Friend</title>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">
                <h1>Baby Care</h1>
            </div>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="baby-profile.php">Baby Profile</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="home" class="hero">
            <h2>Welcome to Baby Care</h2>
            <p>Your little one's best friend for all their needs</p>
            <a href="#services" class="cta-button">Explore Our Services</a>
        </section>

        <section id="services" class="services">
            <h2>Our Services</h2>
            <div class="service-grid">
                <div class="service-item">
                    <i class="fas fa-baby"></i>
                    <h3>Infant Care</h3>
                    <p>Specialized care for newborns and infants</p>
                </div>
                <div class="service-item">
                    <i class="fas fa-utensils"></i>
                    <h3>Nutrition</h3>
                    <p>Balanced meal plans for growing babies</p>
                </div>
                <div class="service-item">
                    <i class="fas fa-bed"></i>
                    <h3>Sleep Training</h3>
                    <p>Helping babies develop healthy sleep habits</p>
                </div>
                <div class="service-item">
                    <i class="fas fa-heartbeat"></i>
                    <h3>Health Monitoring</h3>
                    <p>Regular check-ups and health tracking</p>
                </div>
            </div>
        </section>

        <section id="about" class="about">
            <h2>About Us</h2>
            <p>Baby Care is dedicated to providing the best care for your little ones. Our team of experienced professionals ensures that your baby receives the love, attention, and care they deserve.</p>
        </section>

        <section id="contact" class="contact">
            <h2>Contact Us</h2>
            <form id="contact-form">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <textarea name="message" placeholder="Your Message" required></textarea>
                <button type="submit">Send Message</button>
            </form>
        </section>
    </main>

    <footer>
        <div class="footer-content">
            <div class="footer-section">
                <h3>Baby Care</h3>
                <p>Your little one's best friend for all their needs</p>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Connect With Us</h3>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Baby Care. All rights reserved.</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const contactForm = document.getElementById('contact-form');

            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Get form values
                const name = contactForm.elements['name'].value;
                const email = contactForm.elements['email'].value;
                const message = contactForm.elements['message'].value;

                // Here you would typically send the form data to a server
                // For this example, we'll just log it to the console
                console.log('Form submitted:');
                console.log('Name:', name);
                console.log('Email:', email);
                console.log('Message:', message);

                // Clear the form
                contactForm.reset();

                // Show a success message (you can replace this with a more user-friendly notification)
                alert('Thank you for your message! We will get back to you soon.');
            });
        });

    </script>
</body>
</html>
