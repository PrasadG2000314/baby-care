<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vaccinations";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch baby profiles
$sql = "SELECT * FROM babyprofile";
$result = $conn->query($sql);

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_baby'])) {
        // Add new baby
        $name = $_POST['name'];
        $ageYear = $_POST['ageYear'];
        $ageMonth = $_POST['ageMonth'];
        $dob = $_POST['dob'];
        $gender = $_POST['gender'];
        $weight = $_POST['weight'];
        $height = $_POST['height'];
        $bloodGroup = $_POST['bloodGroup'];
        $parentName = $_POST['parentName'];
        $email = $_POST['email'];
        $contactNo = $_POST['contactNo'];
        $address = $_POST['address'];

        $sql = "INSERT INTO babyprofile (name, ageYear, ageMonth, dob, gender, weight, height, bloodGroup, parentName, email, contactNo, address) 
                VALUES ('$name', $ageYear, $ageMonth, '$dob', '$gender', $weight, $height, '$bloodGroup', '$parentName', '$email', '$contactNo', '$address')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('New baby profile added successfully');
                    window.location.href = 'baby-profile.php';
                </script>";
            
        } else {
            echo "<script>alert('Error: " . $sql . "\\n" . $conn->error . "');</script>";
        }
    } elseif (isset($_POST['add_vaccination'])) {
        // Add new vaccination
        $baby_id = $_POST['baby_id'];
        $date = $_POST['date'];
        $vaccine_name = $_POST['vaccine_name'];
        $NumberOfDose = $_POST['NumberOfDose'];

        $sql = "INSERT INTO vaccinations (baby_id, date, vaccine_name, NumberOfDose, created_at) 
                VALUES ($baby_id, '$date', '$vaccine_name', $NumberOfDose, NOW())";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('New vaccination record added successfully');</script>";
        } else {
            echo "<script>alert('Error: " . $sql . "\\n" . $conn->error . "');</script>";
        }
    } elseif (isset($_POST['update_vaccination'])) {
        // Update vaccination
        $Vaccine_ID = $_POST['Vaccine_ID'];
        $date = $_POST['date'];
        $vaccine_name = $_POST['vaccine_name'];
        $NumberOfDose = $_POST['NumberOfDose'];

        $sql = "UPDATE vaccinations SET date='$date', vaccine_name='$vaccine_name', NumberOfDose=$NumberOfDose WHERE Vaccine_ID=$Vaccine_ID";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Vaccination record updated successfully');</script>";
        } else {
            echo "<script>alert('Error: " . $sql . "\\n" . $conn->error . "');</script>";
        }
    } elseif (isset($_POST['delete_vaccination'])) {
        // Delete vaccination
        $Vaccine_ID = $_POST['Vaccine_ID'];

        $sql = "DELETE FROM vaccinations WHERE Vaccine_ID=$Vaccine_ID";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Vaccination record deleted successfully');</script>";
        } else {
            echo "<script>alert('Error: " . $sql . "\\n" . $conn->error . "');</script>";
        }
    }
}

// Fetch vaccinations for a specific baby
function getVaccinations($conn, $baby_id) {
    $sql = "SELECT * FROM vaccinations WHERE baby_id = $baby_id ORDER BY date DESC";
    $result = $conn->query($sql);
    $vaccinations = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $vaccinations[] = $row;
        }
    }
    return $vaccinations;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baby Profiles</title>
    <link rel="stylesheet" href="css/baby-profile.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">
                <h1>Baby Care</h1>
            </div>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="baby-profile.php">Baby Profile</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="baby-profiles">
            <h2>Baby Profiles</h2>
            <div class="profile-grid">
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<div class='profile-card'>";
                        echo "<div class='card-front'>";
                        echo "<h3>" . $row["name"] . "</h3>";
                        echo "<p>Age: " . $row["ageYear"] . " years " . $row["ageMonth"] . " months</p>";
                        echo "<p>DOB: " . $row["dob"] . "</p>";
                        echo "<p>Gender: " . $row["gender"] . "</p>";
                        echo "<p>Weight: " . $row["weight"] . " kg</p>";
                        echo "<p>Height: " . $row["height"] . " cm</p>";
                        echo "<p>Blood Group: " . $row["bloodGroup"] . "</p>";
                        echo "<p>Parent: " . $row["parentName"] . "</p>";
                        echo "<p>Contact: " . $row["contactNo"] . "</p>";
                        echo "<button class='add-vaccination' data-id='" . $row["id"] . "' data-name='" . $row["name"] . "' data-age-year='" . $row["ageYear"] . "' data-age-month='" . $row["ageMonth"] . "' data-dob='" . $row["dob"] . "' data-gender='" . $row["gender"] . "' data-blood-group='" . $row["bloodGroup"] . "'><i class='fas fa-syringe'></i> Add Vaccination</button>";
                        echo "<button class='view-vaccinations' data-id='" . $row["id"] . "'><i class='fas fa-eye'></i> View Vaccinations</button>";
                        echo "</div>";
                        echo "<div class='card-back'>";
                        echo "<h3>Vaccinations for " . $row["name"] . "</h3>";
                        echo "<div class='vaccinations-list'>";
                        $vaccinations = getVaccinations($conn, $row["id"]);
                        if (!empty($vaccinations)) {
                            foreach ($vaccinations as $vaccination) {
                                echo "<div class='vaccination-item'>";
                                echo "<p>Date: " . $vaccination["date"] . "</p>";
                                echo "<p>Vaccine: " . $vaccination["vaccine_name"] . "</p>";
                                echo "<p>Dose: " . $vaccination["NumberOfDose"] . "</p>";
                                echo "<button class='update-vaccination' data-id='" . $vaccination["Vaccine_ID"] . "' data-date='" . $vaccination["date"] . "' data-vaccine='" . $vaccination["vaccine_name"] . "' data-dose='" . $vaccination["NumberOfDose"] . "' style='background-color: #4CAF50; color: white; border: none; padding: 5px 10px; margin-right: 5px; cursor: pointer;'><i class='fas fa-edit'></i> Update</button>";
                                echo "<button class='delete-vaccination' data-id='" . $vaccination["Vaccine_ID"] . "' style='background-color: #f44336; color: white; border: none; padding: 5px 10px; cursor: pointer;'><i class='fas fa-trash'></i> Delete</button>";
                                echo "</div>";                            }
                        } else {
                            echo "<p>No vaccinations recorded.</p>";
                        }
                        echo "</div>";
                        echo "<button class='flip-card'>Back to Profile</button>";
                        echo "</div>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No baby profiles found.</p>";
                }
                ?>
            </div>
            <button id="add-baby-btn" class="add-baby">Add New Baby</button>
        </section>
    </main>

    <div id="add-baby-modal" class="modal">
        <div class="modal-content">
            <span class="close">×</span>
            <h2>Add New Baby</h2>
            <form id="add-baby-form" method="POST">
                <input type="hidden" name="add_baby" value="1">
                <input type="text" name="name" placeholder="Name" required>
                <input type="number" name="ageYear" placeholder="Age (Years)" required>
                <input type="number" name="ageMonth" placeholder="Age (Months)" required>
                <input type="date" name="dob" required>
                <select name="gender" required>
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
                <input type="number" name="weight" placeholder="Weight (kg)" step="0.1" required>
                <input type="number" name="height" placeholder="Height (cm)" step="0.1" required>
                <input type="text" name="bloodGroup" placeholder="Blood Group" required>
                <input type="text" name="parentName" placeholder="Parent Name" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="tel" name="contactNo" placeholder="Contact Number" required>
                <textarea name="address" placeholder="Address" required></textarea>
                <button type="submit">Add Baby</button>
            </form>
        </div>
    </div>

    <div id="add-vaccination-modal" class="modal">
        <div class="modal-content">
            <span class="close">×</span>
            <div class="vaccination-container">
                <div class="baby-details">
                    <h2>Baby Details</h2>
                    <div id="selected-baby-details"></div>
                </div>
                <div class="vaccination-form">
                    <h2>Add Vaccination</h2>
                    <form id="add-vaccination-form" method="POST">
                        <input type="hidden" name="add_vaccination" value="1">
                        <input type="hidden" name="baby_id" id="baby_id">
                        <input type="date" name="date" required>
                        <input type="text" name="vaccine_name" placeholder="Vaccine Name" required>
                        <input type="number" name="NumberOfDose" placeholder="Number of Dose" required>
                        <button type="submit">Add Vaccination</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div id="update-vaccination-modal" class="modal">
        <div class="modal-content">
            <span class="close">×</span>
            <h2>Update Vaccination</h2>
            <form id="update-vaccination-form" method="POST">
                <input type="hidden" name="update_vaccination" value="1">
                <input type="hidden" name="Vaccine_ID" id="update_Vaccine_ID">
                <input type="date" name="date" id="update_date" required>
                <input type="text" name="vaccine_name" id="update_vaccine_name" placeholder="Vaccine Name" required>
                <input type="number" name="NumberOfDose" id="update_NumberOfDose" placeholder="Number of Dose" required>
                <button type="submit">Update Vaccination</button>
            </form>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <div class="footer-section">
                <h3>Baby Care</h3>
                <p>Your little one's best friend for all their needs</p>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Connect With Us</h3>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Baby Care. All rights reserved.</p>
        </div>
    </footer>

    <script>
        const addBabyBtn = document.getElementById("add-baby-btn");
        const addBabyModal = document.getElementById("add-baby-modal");
        const addVaccinationModal = document.getElementById("add-vaccination-modal");
        const updateVaccinationModal = document.getElementById("update-vaccination-modal");
        const closeBtns = document.getElementsByClassName("close");
        const addVaccinationBtns = document.getElementsByClassName("add-vaccination");
        const viewVaccinationsBtns = document.getElementsByClassName("view-vaccinations");
        const flipCardBtns = document.getElementsByClassName("flip-card");
        const updateVaccinationBtns = document.getElementsByClassName("update-vaccination");
        const deleteVaccinationBtns = document.getElementsByClassName("delete-vaccination");

        addBabyBtn.onclick = function() {
            addBabyModal.style.display = "block";
        }

        for (let btn of closeBtns) {
            btn.onclick = function() {
                addBabyModal.style.display = "none";
                addVaccinationModal.style.display = "none";
                updateVaccinationModal.style.display = "none";
            }
        }

        for (let btn of addVaccinationBtns) {
            btn.onclick = function() {
                const babyId = this.getAttribute("data-id");
                const name = this.getAttribute("data-name");
                const ageYear = this.getAttribute("data-age-year");
                const ageMonth = this.getAttribute("data-age-month");
                const dob = this.getAttribute("data-dob");
                const gender = this.getAttribute("data-gender");
                const bloodGroup = this.getAttribute("data-blood-group");

                document.getElementById("baby_id").value = babyId;
                
                const detailsHtml = `
                    <p><strong>Name:</strong> ${name}</p>
                    <p><strong>Age:</strong> ${ageYear} years ${ageMonth} months</p>
                    <p><strong>DOB:</strong> ${dob}</p>
                    <p><strong>Gender:</strong> ${gender}</p>
                    <p><strong>Blood Group:</strong> ${bloodGroup}</p>
                `;
                document.getElementById("selected-baby-details").innerHTML = detailsHtml;
                addVaccinationModal.style.display = "block";
            }
        }

        for (let btn of viewVaccinationsBtns) {
            btn.onclick = function() {
                const card = this.closest('.profile-card');
                card.classList.add('flipped');
            }
        }

        for (let btn of flipCardBtns) {
            btn.onclick = function() {
                const card = this.closest('.profile-card');
                card.classList.remove('flipped');
            }
        }

        for (let btn of updateVaccinationBtns) {
            btn.onclick = function() {
                const vaccinationId = this.getAttribute("data-id");
                const date = this.getAttribute("data-date");
                const vaccine = this.getAttribute("data-vaccine");
                const dose = this.getAttribute("data-dose");

                document.getElementById("update_Vaccine_ID").value = vaccinationId;
                document.getElementById("update_date").value = date;
                document.getElementById("update_vaccine_name").value = vaccine;
                document.getElementById("update_NumberOfDose").value = dose;

                updateVaccinationModal.style.display = "block";
            }
        }

        for (let btn of deleteVaccinationBtns) {
            btn.onclick = function() {
                const vaccinationId = this.getAttribute("data-id");
                if (confirm("Are you sure you want to delete this vaccination record?")) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.innerHTML = `
                        <input type="hidden" name="delete_vaccination" value="1">
                        <input type="hidden" name="Vaccine_ID" value="${vaccinationId}">
                    `;
                    document.body.appendChild(form);
                    form.submit();
                }
            }
        }

        window.onclick = function(event) {
            if (event.target == addBabyModal) {
                addBabyModal.style.display = "none";
            }
            if (event.target == addVaccinationModal) {
                addVaccinationModal.style.display = "none";
            }
            if (event.target == updateVaccinationModal) {
                updateVaccinationModal.style.display = "none";
            }
        }
    </script>
</body>
</html>
